#! /bin/bash

make -C docs/ html