Devlog
======

V 0.0.3
-------
There is now a rudementrary regex sets ``[a-z]``, ``[13579]``, and so on. Sets 
are used to clear `exercise 2`_. 

.. raw:: html

   <iframe
      src="demo/repl/?kernel=python&code=from%20RegexRiot%20import%20*%0ABEGINING.then(one_or_more(ANYTHING)).then(OPEN_PARENTHESIS) \%0A
        .then(1).then(DIGIT).then(riot(0, to=8)).then(DIGIT) \%0A
        .then(CLOSE_PARENTHESIS)"
      width="100%"
      height="300"
   ></iframe>

.. _exercise 2: http://regextutorials.com/excercise.html?Years%20before%201990

V 0.0.2
-------
A made this new version because I couldn't edit the description of the project 
on PyPi.org for V 0.0.1

V 0.0.1
-------
This was the first version