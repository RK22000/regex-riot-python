RiotString
==========

``RiotString``\s are how regex is represented in this library. 

.. automodule:: RegexRiot._riot
    :members:
