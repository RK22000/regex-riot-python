Basic Expressions
=================

``RegexRiot`` comes with a few basic expression you can use as individual 
building blocks to build your regex.

.. automodule:: RegexRiot._basic_expressions
    :members: