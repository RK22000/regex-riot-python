RegexTutorials
==============

These are tests based on the exercises on `REGEXTUTORIALS`_. 

.. REGEXTUTORIALS: http://regextutorials.com/index.html

.. automodule:: tests.test_regextutorials
    :members:
    :undoc-members: