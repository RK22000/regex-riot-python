#! /bin/bash

python -m http.server --directory ./docs/build/html/